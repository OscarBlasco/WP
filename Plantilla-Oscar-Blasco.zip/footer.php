<footer class="main-footer">
		<div class="container">
			<div class="f_left">
				
				<br>
				<ul>
					<li><a href="http://localhost/wordpress/">Inicio</a></li>
					<li><a href="http://localhost/wordpress/contacto/">Contacto</a></li>
					<li><a title="Facebook" href="https://www.facebook.com/bodegasblascoteulada/"><img width="38px" src="https://image.flaticon.com/icons/png/512/124/124010.png" alt="Facebook" /></a></li>
					
				
				</ul>
				<br><br><p>&copy; 2019 - Tema por Oscar Blasco</p>
			</div>
			<div class="f_right">
				
				<p><a href="http://localhost/wordpress/ubicacion/">Dirección: C/ gremis 5.Poligono Industrial Teulada</a><br><br>
Teléfono: 96 574 12 86 <br>
Email: bodega@bodegasblasco.es</p>
			</div>

		</div>
	</footer>
	<?php wp_footer(); ?>
</body>
</html>